Tăbîrcă Natalia-Mihaela 322CA

structura fisiere:
    -> main: 
            - Main - citesc inputul, încep jocul și afisez rezultatele
            - Input - formatul inputului 
            - InputLoader - cu ajutorul API-ului citesc din fisier datele 
        de intrare și returnez informatiile care imi sunt necesare
    -> hero:
            - Hero - clasa abstracta care modelează eroul. Contine metode
        pentru: 
                > cresterea nivelului (în care se creste implicit HP ul)
                > verificarea daca eroul curent se află în același loc 
            cu altul dat ca parametru
                > aplicare Overtime Damage pe campion
                > metoda "accept" pentru crearea unui Double Dispatch care 
            aplica o abilitate unui tip de erou
                > metoda "fightOpponent" în care se apeleaza accept pentru 
            rasa potrivita
                > "toString" 
                        __
            - Knight      |   clase care extind Hero si contin metode proprii
            - Pyromancer  |__ precum "maxHp" care întoarce hp-ul maxim al unui erou
            - Rogue       |   la un anumit nivel, sau "flatDamage" care returnează
            - Wizard    __|   valoarea damage-ului eroului fara amplificarea de rasa

            - AllHeroes: - clasa care implementeaza metode aplicabile întregii 
                    colecții de eroi:
                        > findOpponent: gaseste adversarul eroului curent
                        > moveHeroes: muta eroii la inceputul rundei pe pozitiile 
                    indicate
                        > applyOvertimeDamage: aplica dot tuturor eroilor care primesc 
                    odt in runda curenta
                        > startFight: mutarea eroilor + aplicarea odt + 
                    + lupta propriu-zisa în care fiecare erou îșî găsește adversarul,
                    se atacă reciproc și, daca e cazul, se adauga hp si se crește nivelul 


    -> abilities:
            - AbilitiesVisitor - interfata care modeleaza metodele visit pentru rase
                        ___
            - Execute      |    
            - Slam         |    
            - Fireblast    |     
            - Ignite       |____ clase care implementeaza interfata AbilitiesVisitor
            - Backstab     |     Fiecare implementeaza metodele visit astfel încât
            - Paralysis    |     eroul dat ca parametru metodei sa primeasca damage-ul
            - Deflect      |     definit de clasa corespunzatoare
            - Drain     ___|

    -> constants:
            - Constants: declararea tuturor constantelor necesare in cod